document.getElementById('scanButton').addEventListener('click',()=>{
const loading=document.getElementById('loading');
const result=document.getElementById('idea-result');
loading.style.display='block';
setTimeout(()=>{loading.style.display='none';result.textContent='Mock wallet analysis complete!';},2500);
});